from distutils.core import setup
setup(
  name = 'API_WEB__FLASK_BOOTSTRAP_TRADING',
  packages = ['API_WEB__FLASK_BOOTSTRAP_TRADING'],
  version = '0.1',
  description = 'Trading library',
  author = 'Angello Rodriguez Gutierrez, Carlos Eduardo Gomez Fandino',
  author_email = 'angellorodriguez@campusciff.net, carlosgomez@campusciff.net',
  url = 'git@github.com:AngelloXtr/API_WEB__FLASK_BOOTSTRAP_TRADING.git', 
  download_url = 'git@github.com:AngelloXtr/API_WEB__FLASK_BOOTSTRAP_TRADING.targz',
  keywords = ['testing', 'logging', 'example'],
  classifiers = [],
)
